import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, supabaseEnabled } from '../lib/supabase.js';

const STORAGE_KEY = 'field-daily-inventory-v1';
const ROW_ID = 'main';
const DEBOUNCE_MS = 400;

// status values: 'connecting' | 'synced' | 'saving' | 'offline' | 'local'

export function useInventory(initEmpty) {
  const [inv, setInv] = useState(initEmpty);
  const [status, setStatus] = useState(supabaseEnabled ? 'connecting' : 'local');
  const saveTimer = useRef(null);
  const lastSavedRef = useRef(null);

  // Load initial data
  useEffect(() => {
    let cancelled = false;

    async function load() {
      // Always try localStorage first for instant paint
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw && !cancelled) {
          const parsed = JSON.parse(raw);
          const base = initEmpty();
          setInv({
            garage: { ...base.garage, ...(parsed.garage || {}) },
            truck: { ...base.truck, ...(parsed.truck || {}) },
            notes: parsed.notes || '',
          });
        }
      } catch (e) {
        // ignore
      }

      if (!supabaseEnabled) {
        setStatus('local');
        return;
      }

      // Then load fresh from Supabase
      try {
        const { data, error } = await supabase
          .from('inventory')
          .select('data')
          .eq('id', ROW_ID)
          .maybeSingle();

        if (cancelled) return;
        if (error) throw error;

        if (data && data.data) {
          const base = initEmpty();
          setInv({
            garage: { ...base.garage, ...(data.data.garage || {}) },
            truck: { ...base.truck, ...(data.data.truck || {}) },
            notes: data.data.notes || '',
          });
        }
        setStatus('synced');
      } catch (e) {
        console.warn('Supabase load failed, staying on local data', e);
        setStatus('offline');
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  // Realtime subscription for changes from other devices
  useEffect(() => {
    if (!supabaseEnabled) return;

    const channel = supabase
      .channel('inventory-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'inventory',
          filter: `id=eq.${ROW_ID}`,
        },
        (payload) => {
          if (!payload.new || !payload.new.data) return;
          const remoteStr = JSON.stringify(payload.new.data);
          // Ignore echoes of our own writes
          if (remoteStr === lastSavedRef.current) return;

          const base = initEmpty();
          const remote = payload.new.data;
          setInv({
            garage: { ...base.garage, ...(remote.garage || {}) },
            truck: { ...base.truck, ...(remote.truck || {}) },
            notes: remote.notes || '',
          });
          setStatus('synced');

          // Mirror to localStorage
          try {
            localStorage.setItem(STORAGE_KEY, remoteStr);
          } catch (e) {
            // ignore
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const persist = useCallback(async (data) => {
    // Always save to localStorage as a safety net
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      // ignore
    }

    if (!supabaseEnabled) return;

    setStatus('saving');
    try {
      lastSavedRef.current = JSON.stringify(data);
      const { error } = await supabase.from('inventory').upsert({
        id: ROW_ID,
        data,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      setStatus('synced');
    } catch (e) {
      console.warn('Supabase save failed', e);
      setStatus('offline');
    }
  }, []);

  const update = useCallback(
    (updater) => {
      setInv((prev) => {
        const next = typeof updater === 'function' ? updater(prev) : updater;
        if (saveTimer.current) clearTimeout(saveTimer.current);
        saveTimer.current = setTimeout(() => persist(next), DEBOUNCE_MS);
        return next;
      });
    },
    [persist]
  );

  return { inv, update, status };
}
