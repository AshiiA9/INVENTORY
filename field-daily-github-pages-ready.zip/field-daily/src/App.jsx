import React, { useState } from 'react';
import {
  Plus,
  Minus,
  ArrowLeftRight,
  Warehouse,
  Truck,
  AlertTriangle,
  X,
  Check,
  RotateCcw,
  Cloud,
  CloudOff,
  Loader2,
  HardDrive,
} from 'lucide-react';
import { useInventory } from './hooks/useInventory.js';

const PRODUCT_CATEGORIES = [
  {
    id: 'general',
    name: 'General Pest',
    products: [
      { id: 'crosscheck', name: 'Crosscheck', sub: 'Lesco' },
      { id: 'gentrol-ic3', name: 'Gentrol IC3' },
      { id: 'alpine-wsg', name: 'Alpine WSG' },
      { id: 'delta-dust', name: 'Delta Dust' },
    ],
  },
  {
    id: 'ants',
    name: 'Ants',
    products: [{ id: 'taurus-sc', name: 'Taurus SC' }],
  },
  {
    id: 'termite',
    name: 'Termite',
    products: [{ id: 'termidor-he', name: 'Termidor HE' }],
  },
  {
    id: 'mosquito',
    name: 'Mosquito',
    products: [{ id: 'in2care', name: 'In2Care refill packets', sub: '25 per bag' }],
  },
  {
    id: 'bait-stations',
    name: 'Bait Stations',
    products: [{ id: 'trelona', name: 'Trelona bait stations' }],
  },
  {
    id: 'rodent',
    name: 'Rodent',
    products: [
      { id: 'niban', name: 'Niban granular' },
      { id: 'weighted-station', name: 'Weighted outdoor rodent station' },
      { id: 'indoor-station', name: 'Indoor rodent station' },
      { id: 'contrac', name: 'Contrac bloc or Final' },
      { id: 'sticky-traps', name: 'Sticky/glue traps' },
    ],
  },
];

const ALL_PRODUCTS = PRODUCT_CATEGORIES.flatMap((c) => c.products);

const THEME = {
  bg: '#EFEDE4',
  canvas: '#FFFFFF',
  ink: '#1A1917',
  ink2: '#6B6862',
  ink3: '#A09C93',
  line: '#E2DED0',
  lineSoft: '#EDE9DC',
  garage: '#34534A',
  garageSoft: '#E4EBE7',
  truck: '#425063',
  truckSoft: '#E5E8EE',
  low: '#8A5A1F',
  lowSoft: '#F2E9D5',
  zero: '#8F2F22',
  zeroSoft: '#F1DFDA',
};

const FONT = {
  display: `'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif`,
  body: `'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif`,
  mono: `'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, monospace`,
};

function initEmpty() {
  const g = {};
  const t = {};
  ALL_PRODUCTS.forEach((p) => {
    g[p.id] = 0;
    t[p.id] = 0;
  });
  return { garage: g, truck: t, notes: '' };
}

function statusFor(n) {
  if (n === 0) return 'zero';
  if (n <= 2) return 'low';
  return 'ok';
}

export default function App() {
  const [location, setLocation] = useState('garage');
  const { inv, update, status: syncStatus } = useInventory(initEmpty);
  const [transferFor, setTransferFor] = useState(null);
  const [transferAmt, setTransferAmt] = useState('1');
  const [showReset, setShowReset] = useState(false);

  const adjust = (productId, delta) => {
    update((prev) => {
      const cur = prev[location][productId] || 0;
      const nextVal = Math.max(0, cur + delta);
      return {
        ...prev,
        [location]: { ...prev[location], [productId]: nextVal },
      };
    });
  };

  const setDirect = (productId, val) => {
    const n = Math.max(0, parseInt(val, 10) || 0);
    update((prev) => ({
      ...prev,
      [location]: { ...prev[location], [productId]: n },
    }));
  };

  const doTransfer = () => {
    if (!transferFor) return;
    const amt = Math.max(0, parseInt(transferAmt, 10) || 0);
    if (amt <= 0) return;
    const available = inv.garage[transferFor.id] || 0;
    const actual = Math.min(amt, available);
    if (actual <= 0) return;
    update((prev) => ({
      ...prev,
      garage: {
        ...prev.garage,
        [transferFor.id]: (prev.garage[transferFor.id] || 0) - actual,
      },
      truck: {
        ...prev.truck,
        [transferFor.id]: (prev.truck[transferFor.id] || 0) + actual,
      },
    }));
    setTransferFor(null);
    setTransferAmt('1');
  };

  const resetAll = () => {
    update(() => initEmpty());
    setShowReset(false);
  };

  const accent = location === 'garage' ? THEME.garage : THEME.truck;

  return (
    <div
      style={{
        background: THEME.bg,
        minHeight: '100vh',
        fontFamily: FONT.body,
        color: THEME.ink,
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div style={{ maxWidth: 560, margin: '0 auto' }}>
        {/* Header */}
        <header style={{ padding: '24px 20px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <div>
              <div
                style={{
                  fontSize: 10,
                  letterSpacing: '0.22em',
                  color: THEME.ink3,
                  textTransform: 'uppercase',
                  fontWeight: 500,
                }}
              >
                Shield Pest Appalachia
              </div>
              <h1
                style={{
                  fontFamily: FONT.display,
                  fontSize: 28,
                  fontWeight: 700,
                  letterSpacing: '-0.02em',
                  marginTop: 4,
                  marginBottom: 0,
                  lineHeight: 1,
                }}
              >
                Field Daily
              </h1>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <SyncBadge status={syncStatus} />
              <button
                onClick={() => setShowReset(true)}
                style={{
                  color: THEME.ink3,
                  padding: 8,
                  borderRadius: 8,
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                }}
                title="Reset all counts"
              >
                <RotateCcw size={15} />
              </button>
            </div>
          </div>
          <div
            style={{
              marginTop: 12,
              fontSize: 12,
              color: THEME.ink2,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <span>Technician</span>
            <span style={{ color: THEME.ink, fontWeight: 500 }}>Ashton</span>
          </div>
        </header>

        {/* Location toggle */}
        <div style={{ padding: '0 20px 20px' }}>
          <div
            style={{
              background: THEME.canvas,
              border: `1px solid ${THEME.line}`,
              borderRadius: 14,
              padding: 4,
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              position: 'relative',
            }}
          >
            <LocButton
              active={location === 'garage'}
              onClick={() => setLocation('garage')}
              icon={<Warehouse size={16} strokeWidth={1.75} />}
              label="Garage"
              accent={THEME.garage}
            />
            <LocButton
              active={location === 'truck'}
              onClick={() => setLocation('truck')}
              icon={<Truck size={16} strokeWidth={1.75} />}
              label="Silver Truck"
              accent={THEME.truck}
            />
          </div>
        </div>

        {/* Categories */}
        <main style={{ padding: '0 20px 32px' }}>
          {PRODUCT_CATEGORIES.map((cat, idx) => (
            <section key={cat.id} style={{ marginTop: idx === 0 ? 0 : 24 }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  marginBottom: 8,
                  padding: '0 4px',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div
                    style={{
                      width: 3,
                      height: 12,
                      background: accent,
                      borderRadius: 1,
                    }}
                  />
                  <h2
                    style={{
                      fontFamily: FONT.display,
                      fontSize: 11,
                      letterSpacing: '0.18em',
                      textTransform: 'uppercase',
                      fontWeight: 600,
                      color: THEME.ink,
                      margin: 0,
                    }}
                  >
                    {cat.name}
                  </h2>
                </div>
                <div
                  style={{
                    fontSize: 10,
                    color: THEME.ink3,
                    fontFamily: FONT.mono,
                    letterSpacing: '0.05em',
                  }}
                >
                  {cat.products.length} {cat.products.length === 1 ? 'item' : 'items'}
                </div>
              </div>

              <div
                style={{
                  background: THEME.canvas,
                  border: `1px solid ${THEME.line}`,
                  borderRadius: 14,
                  overflow: 'hidden',
                }}
              >
                {cat.products.map((p, i) => {
                  const count = inv[location][p.id] || 0;
                  const otherCount =
                    inv[location === 'garage' ? 'truck' : 'garage'][p.id] || 0;
                  return (
                    <ProductRow
                      key={p.id}
                      product={p}
                      count={count}
                      otherCount={otherCount}
                      status={statusFor(count)}
                      location={location}
                      accent={accent}
                      onInc={() => adjust(p.id, 1)}
                      onDec={() => adjust(p.id, -1)}
                      onSet={(v) => setDirect(p.id, v)}
                      onTransfer={() => {
                        setTransferFor(p);
                        setTransferAmt('1');
                      }}
                      showDivider={i < cat.products.length - 1}
                    />
                  );
                })}
              </div>
            </section>
          ))}

          {/* Notes */}
          <section style={{ marginTop: 24 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                marginBottom: 8,
                padding: '0 4px',
              }}
            >
              <div
                style={{
                  width: 3,
                  height: 12,
                  background: accent,
                  borderRadius: 1,
                }}
              />
              <h2
                style={{
                  fontFamily: FONT.display,
                  fontSize: 11,
                  letterSpacing: '0.18em',
                  textTransform: 'uppercase',
                  fontWeight: 600,
                  margin: 0,
                }}
              >
                Additional Notes
              </h2>
            </div>
            <textarea
              value={inv.notes}
              onChange={(e) => update((prev) => ({ ...prev, notes: e.target.value }))}
              placeholder="Anything else worth noting..."
              rows={4}
              style={{
                width: '100%',
                background: THEME.canvas,
                border: `1px solid ${THEME.line}`,
                borderRadius: 14,
                padding: 14,
                fontSize: 14,
                fontFamily: FONT.body,
                color: THEME.ink,
                resize: 'vertical',
                outline: 'none',
              }}
              onFocus={(e) => (e.target.style.borderColor = accent)}
              onBlur={(e) => (e.target.style.borderColor = THEME.line)}
            />
          </section>

          <div
            style={{
              marginTop: 24,
              textAlign: 'center',
              fontSize: 10,
              color: THEME.ink3,
              fontFamily: FONT.mono,
              letterSpacing: '0.08em',
            }}
          >
            {syncStatus === 'local'
              ? 'AUTO-SAVED · THIS DEVICE ONLY'
              : syncStatus === 'offline'
              ? 'AUTO-SAVED LOCALLY · WILL RESYNC WHEN ONLINE'
              : 'AUTO-SAVED · SYNCED ACROSS DEVICES'}
          </div>
        </main>
      </div>

      {transferFor && (
        <TransferModal
          product={transferFor}
          garageCount={inv.garage[transferFor.id] || 0}
          truckCount={inv.truck[transferFor.id] || 0}
          amount={transferAmt}
          setAmount={setTransferAmt}
          onConfirm={doTransfer}
          onCancel={() => {
            setTransferFor(null);
            setTransferAmt('1');
          }}
        />
      )}

      {showReset && (
        <ResetModal onConfirm={resetAll} onCancel={() => setShowReset(false)} />
      )}
    </div>
  );
}

function SyncBadge({ status }) {
  const config = {
    connecting: { icon: Loader2, label: 'Connecting', color: THEME.ink3, bg: THEME.lineSoft, spin: true },
    synced: { icon: Cloud, label: 'Synced', color: THEME.garage, bg: THEME.garageSoft },
    saving: { icon: Loader2, label: 'Saving', color: THEME.truck, bg: THEME.truckSoft, spin: true },
    offline: { icon: CloudOff, label: 'Offline', color: THEME.low, bg: THEME.lowSoft },
    local: { icon: HardDrive, label: 'Local', color: THEME.ink3, bg: THEME.lineSoft },
  }[status] || { icon: HardDrive, label: 'Local', color: THEME.ink3, bg: THEME.lineSoft };

  const Icon = config.icon;

  return (
    <div
      title={
        status === 'local'
          ? 'Backend not configured — data lives only in this browser'
          : status === 'offline'
          ? "Can't reach the backend right now — changes save locally and will sync when reachable"
          : status === 'connecting'
          ? 'Connecting to backend...'
          : status === 'saving'
          ? 'Saving changes to the cloud...'
          : 'Synced with the cloud — changes appear on other devices in real time'
      }
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '4px 8px',
        borderRadius: 999,
        background: config.bg,
        color: config.color,
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
      }}
    >
      <Icon
        size={11}
        strokeWidth={2.25}
        style={config.spin ? { animation: 'spin 1s linear infinite' } : undefined}
      />
      <span>{config.label}</span>
    </div>
  );
}

function LocButton({ active, onClick, icon, label, accent }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: active ? accent : 'transparent',
        color: active ? '#fff' : THEME.ink2,
        borderRadius: 10,
        padding: '12px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        fontSize: 14,
        fontWeight: 600,
        letterSpacing: '-0.01em',
        transition: 'all 0.18s ease',
        cursor: 'pointer',
        border: 'none',
      }}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function ProductRow({
  product,
  count,
  otherCount,
  status,
  location,
  accent,
  onInc,
  onDec,
  onSet,
  onTransfer,
  showDivider,
}) {
  const [editing, setEditing] = useState(false);
  const [editVal, setEditVal] = useState(String(count));

  const commitEdit = () => {
    onSet(editVal);
    setEditing(false);
  };

  const statusColor =
    status === 'ok' ? THEME.ink : status === 'low' ? THEME.low : THEME.zero;

  return (
    <div
      style={{
        padding: '14px',
        borderBottom: showDivider ? `1px solid ${THEME.lineSoft}` : 'none',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: 15,
            fontWeight: 500,
            color: THEME.ink,
            letterSpacing: '-0.01em',
            lineHeight: 1.25,
          }}
        >
          {product.name}
        </div>
        {product.sub && (
          <div style={{ fontSize: 11, color: THEME.ink3, marginTop: 2 }}>
            {product.sub}
          </div>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, flexWrap: 'wrap' }}>
          {status !== 'ok' && (
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
                fontSize: 10,
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                fontWeight: 600,
                color: status === 'zero' ? THEME.zero : THEME.low,
                background: status === 'zero' ? THEME.zeroSoft : THEME.lowSoft,
                padding: '2px 6px',
                borderRadius: 4,
              }}
            >
              <AlertTriangle size={9} strokeWidth={2.5} />
              {status === 'zero' ? 'Out' : 'Low'}
            </div>
          )}
          <div
            style={{
              fontSize: 10,
              color: THEME.ink3,
              fontFamily: FONT.mono,
              letterSpacing: '0.03em',
            }}
          >
            {location === 'truck' ? 'GARAGE' : 'TRUCK'}: {otherCount}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
        <button
          onClick={onDec}
          disabled={count === 0}
          style={{
            width: 30,
            height: 30,
            borderRadius: 8,
            background: count === 0 ? 'transparent' : THEME.bg,
            border: `1px solid ${count === 0 ? THEME.lineSoft : THEME.line}`,
            color: count === 0 ? THEME.ink3 : THEME.ink,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: count === 0 ? 'not-allowed' : 'pointer',
            transition: 'all 0.15s',
          }}
        >
          <Minus size={14} strokeWidth={2} />
        </button>

        {editing ? (
          <input
            type="number"
            value={editVal}
            onChange={(e) => setEditVal(e.target.value)}
            onBlur={commitEdit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') commitEdit();
              if (e.key === 'Escape') {
                setEditVal(String(count));
                setEditing(false);
              }
            }}
            autoFocus
            style={{
              width: 48,
              height: 32,
              textAlign: 'center',
              fontFamily: FONT.mono,
              fontSize: 16,
              fontWeight: 600,
              border: `1.5px solid ${accent}`,
              borderRadius: 8,
              outline: 'none',
              color: THEME.ink,
              background: '#fff',
              fontVariantNumeric: 'tabular-nums',
            }}
          />
        ) : (
          <button
            onClick={() => {
              setEditVal(String(count));
              setEditing(true);
            }}
            style={{
              minWidth: 44,
              height: 32,
              padding: '0 6px',
              fontFamily: FONT.mono,
              fontSize: 17,
              fontWeight: 600,
              fontVariantNumeric: 'tabular-nums',
              textAlign: 'center',
              background: 'transparent',
              border: 'none',
              cursor: 'text',
              letterSpacing: '-0.01em',
              color: statusColor,
            }}
            title="Tap to edit directly"
          >
            {count}
          </button>
        )}

        <button
          onClick={onInc}
          style={{
            width: 30,
            height: 30,
            borderRadius: 8,
            background: THEME.bg,
            border: `1px solid ${THEME.line}`,
            color: THEME.ink,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.15s',
          }}
        >
          <Plus size={14} strokeWidth={2} />
        </button>

        {location === 'truck' && (
          <button
            onClick={onTransfer}
            disabled={otherCount === 0}
            style={{
              marginLeft: 4,
              height: 30,
              padding: '0 10px',
              borderRadius: 8,
              background: otherCount === 0 ? THEME.bg : accent,
              color: otherCount === 0 ? THEME.ink3 : '#fff',
              fontSize: 11,
              fontWeight: 600,
              letterSpacing: '0.02em',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: 4,
              cursor: otherCount === 0 ? 'not-allowed' : 'pointer',
              transition: 'all 0.15s',
              whiteSpace: 'nowrap',
            }}
            title={
              otherCount === 0
                ? 'Nothing in garage to transfer'
                : 'Transfer from garage to truck'
            }
          >
            <ArrowLeftRight size={12} strokeWidth={2.25} />
            <span>From Garage</span>
          </button>
        )}
      </div>
    </div>
  );
}

function TransferModal({
  product,
  garageCount,
  truckCount,
  amount,
  setAmount,
  onConfirm,
  onCancel,
}) {
  const amt = Math.max(0, parseInt(amount, 10) || 0);
  const canTransfer = amt > 0 && amt <= garageCount;
  const willExceed = amt > garageCount;

  return (
    <div
      className="modal-backdrop"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(20, 20, 18, 0.55)',
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        zIndex: 50,
        backdropFilter: 'blur(4px)',
      }}
      onClick={onCancel}
    >
      <div
        className="modal-panel"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: THEME.canvas,
          borderRadius: '20px 20px 0 0',
          width: '100%',
          maxWidth: 520,
          padding: 24,
          paddingBottom: 'calc(24px + env(safe-area-inset-bottom))',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            marginBottom: 16,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 10,
                letterSpacing: '0.18em',
                textTransform: 'uppercase',
                color: THEME.ink3,
                fontWeight: 600,
              }}
            >
              Transfer to Truck
            </div>
            <div
              style={{
                fontSize: 20,
                fontWeight: 600,
                marginTop: 4,
                letterSpacing: '-0.01em',
              }}
            >
              {product.name}
            </div>
            {product.sub && (
              <div style={{ fontSize: 12, color: THEME.ink3, marginTop: 2 }}>
                {product.sub}
              </div>
            )}
          </div>
          <button
            onClick={onCancel}
            style={{
              padding: 6,
              borderRadius: 8,
              color: THEME.ink2,
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              display: 'flex',
            }}
          >
            <X size={18} />
          </button>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr auto 1fr',
            gap: 12,
            alignItems: 'center',
            marginBottom: 20,
          }}
        >
          <StockCard
            label="Garage"
            count={garageCount}
            accent={THEME.garage}
            soft={THEME.garageSoft}
          />
          <ArrowLeftRight size={20} strokeWidth={1.5} color={THEME.ink3} />
          <StockCard
            label="Silver Truck"
            count={truckCount}
            accent={THEME.truck}
            soft={THEME.truckSoft}
          />
        </div>

        <div style={{ marginBottom: 16 }}>
          <label
            style={{
              fontSize: 11,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: THEME.ink2,
              fontWeight: 600,
            }}
          >
            Amount to transfer
          </label>
          <div style={{ display: 'flex', gap: 8, marginTop: 8, alignItems: 'center' }}>
            <button
              onClick={() => setAmount(String(Math.max(1, amt - 1)))}
              style={{
                width: 44,
                height: 48,
                borderRadius: 10,
                background: THEME.bg,
                border: `1px solid ${THEME.line}`,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Minus size={16} />
            </button>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="1"
              max={garageCount}
              style={{
                flex: 1,
                minWidth: 0,
                height: 48,
                textAlign: 'center',
                fontFamily: FONT.mono,
                fontSize: 22,
                fontWeight: 700,
                border: `1.5px solid ${willExceed ? THEME.zero : THEME.line}`,
                borderRadius: 10,
                outline: 'none',
                background: '#fff',
                fontVariantNumeric: 'tabular-nums',
                color: willExceed ? THEME.zero : THEME.ink,
              }}
            />
            <button
              onClick={() => setAmount(String(Math.min(garageCount, amt + 1)))}
              style={{
                width: 44,
                height: 48,
                borderRadius: 10,
                background: THEME.bg,
                border: `1px solid ${THEME.line}`,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Plus size={16} />
            </button>
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            {[1, 5, 10].filter((v) => v <= garageCount).map((v) => (
              <button
                key={v}
                onClick={() => setAmount(String(v))}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  fontSize: 12,
                  fontWeight: 600,
                  background: 'transparent',
                  border: `1px solid ${THEME.line}`,
                  borderRadius: 8,
                  color: THEME.ink2,
                  cursor: 'pointer',
                  fontFamily: FONT.mono,
                }}
              >
                {v}
              </button>
            ))}
            {garageCount > 0 && (
              <button
                onClick={() => setAmount(String(garageCount))}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  fontSize: 12,
                  fontWeight: 600,
                  background: 'transparent',
                  border: `1px solid ${THEME.line}`,
                  borderRadius: 8,
                  color: THEME.ink2,
                  cursor: 'pointer',
                  fontFamily: FONT.mono,
                  letterSpacing: '0.02em',
                }}
              >
                ALL ({garageCount})
              </button>
            )}
          </div>
          {willExceed && (
            <div
              style={{
                marginTop: 8,
                fontSize: 12,
                color: THEME.zero,
                display: 'flex',
                alignItems: 'center',
                gap: 6,
              }}
            >
              <AlertTriangle size={13} />
              Only {garageCount} available in the garage
            </div>
          )}
        </div>

        {canTransfer && (
          <div
            style={{
              background: THEME.bg,
              borderRadius: 10,
              padding: 12,
              fontSize: 12,
              color: THEME.ink2,
              marginBottom: 16,
              fontFamily: FONT.mono,
              letterSpacing: '0.02em',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span>GARAGE</span>
              <span>
                <span style={{ color: THEME.ink3 }}>{garageCount}</span>
                <span style={{ margin: '0 6px', color: THEME.ink3 }}>→</span>
                <span style={{ color: THEME.garage, fontWeight: 700 }}>
                  {garageCount - amt}
                </span>
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>TRUCK</span>
              <span>
                <span style={{ color: THEME.ink3 }}>{truckCount}</span>
                <span style={{ margin: '0 6px', color: THEME.ink3 }}>→</span>
                <span style={{ color: THEME.truck, fontWeight: 700 }}>
                  {truckCount + amt}
                </span>
              </span>
            </div>
          </div>
        )}

        <div style={{ display: 'flex', gap: 10 }}>
          <button
            onClick={onCancel}
            style={{
              flex: 1,
              height: 48,
              borderRadius: 12,
              background: 'transparent',
              border: `1px solid ${THEME.line}`,
              color: THEME.ink,
              fontWeight: 600,
              fontSize: 14,
              cursor: 'pointer',
            }}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={!canTransfer}
            style={{
              flex: 2,
              height: 48,
              borderRadius: 12,
              background: canTransfer ? THEME.truck : THEME.line,
              color: canTransfer ? '#fff' : THEME.ink3,
              fontWeight: 600,
              fontSize: 14,
              border: 'none',
              cursor: canTransfer ? 'pointer' : 'not-allowed',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 6,
            }}
          >
            <Check size={16} strokeWidth={2.5} />
            Transfer {canTransfer ? amt : ''}
          </button>
        </div>
      </div>
    </div>
  );
}

function StockCard({ label, count, accent, soft }) {
  return (
    <div
      style={{
        background: soft,
        borderRadius: 12,
        padding: '14px 12px',
        textAlign: 'center',
      }}
    >
      <div
        style={{
          fontSize: 9,
          letterSpacing: '0.14em',
          textTransform: 'uppercase',
          color: accent,
          fontWeight: 700,
        }}
      >
        {label}
      </div>
      <div
        style={{
          fontFamily: FONT.mono,
          fontSize: 28,
          fontWeight: 700,
          color: accent,
          marginTop: 4,
          fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.02em',
        }}
      >
        {count}
      </div>
    </div>
  );
}

function ResetModal({ onConfirm, onCancel }) {
  return (
    <div
      className="modal-backdrop"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(20, 20, 18, 0.55)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 50,
        padding: 20,
        backdropFilter: 'blur(4px)',
      }}
      onClick={onCancel}
    >
      <div
        className="modal-panel"
        onClick={(e) => e.stopPropagation()}
        style={{
          background: THEME.canvas,
          borderRadius: 16,
          padding: 24,
          maxWidth: 380,
          width: '100%',
        }}
      >
        <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>
          Reset all counts?
        </div>
        <div
          style={{
            fontSize: 14,
            color: THEME.ink2,
            marginBottom: 20,
            lineHeight: 1.5,
          }}
        >
          Both the garage and silver truck inventories will be set to zero. This can't be undone.
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            onClick={onCancel}
            style={{
              flex: 1,
              height: 44,
              borderRadius: 10,
              background: 'transparent',
              border: `1px solid ${THEME.line}`,
              color: THEME.ink,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            style={{
              flex: 1,
              height: 44,
              borderRadius: 10,
              background: THEME.zero,
              color: '#fff',
              fontWeight: 600,
              border: 'none',
              cursor: 'pointer',
            }}
          >
            Reset all
          </button>
        </div>
      </div>
    </div>
  );
}
