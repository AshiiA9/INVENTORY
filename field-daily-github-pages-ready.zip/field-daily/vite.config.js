import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// GitHub Pages project sites are served from a subfolder like:
// https://YOUR_USERNAME.github.io/field-daily/
// Relative asset paths keep the app working there, in /dist, and even when opened locally.
export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    port: 5173,
    open: true,
  },
});
