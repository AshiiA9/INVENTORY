# Field Daily

Inventory tracker for Shield Pest Appalachia. Two synced inventories (garage and silver truck), one-tap transfers between them, and live sync across every device you sign into.

## What it does

- Toggle between **Garage** and **Silver Truck** views
- Adjust any count with `+` / `−`, or tap the number to type directly
- **From Garage** button on truck view — transfer any amount from garage to truck in one confirmed action, with a live before/after preview
- Automatic **Low** (≤ 2) and **Out** (0) badges
- Notes field
- Reset button (top right)
- Everything auto-saves and syncs to the cloud in real time

## Two ways to run this

**Local-only mode:** works out of the box, no setup. Counts save to the browser via `localStorage`. Fine for one device.

**Synced mode:** counts live in a Supabase database and update in real time across your phone, laptop, and any other device you sign into. Setup takes about 5 minutes.

The app runs in local-only mode automatically if it can't find backend credentials, so you can deploy first and add sync whenever.

---

## Get it running locally

You need Node.js 18+.

```bash
npm install
npm run dev
```

The app opens at `http://localhost:5173`. It'll work immediately in local-only mode.

Production build:

```bash
npm run build
npm run preview
```

The bundle lands in `dist/`.

---

## Set up the backend (~5 minutes)

**1. Create a Supabase account.** Go to [supabase.com](https://supabase.com), click "Start your project", sign in with GitHub.

**2. Create a project.** Click "New Project". Pick any name (e.g. `field-daily`), pick a region close to you, set a database password (save it somewhere), and click "Create". Wait ~1 minute for it to provision.

**3. Set up the table.** In the left sidebar, click **SQL Editor** → **New query**. Open `supabase-setup.sql` from this repo, copy the whole file, paste it in, and click **Run**. You should see "Success. No rows returned."

**4. Grab your keys.** In the left sidebar, click **Project Settings** (gear icon) → **API**. Copy two values:
   - **Project URL** (e.g. `https://abcdefg.supabase.co`)
   - **anon public** key (a long string starting with `eyJ...`)

**5. Wire them into the app.**

For **local dev**, create a `.env` file in the project root:

```
VITE_SUPABASE_URL=https://abcdefg.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
```

Restart `npm run dev`. The badge in the top-right should switch from "LOCAL" to "SYNCED".

For **Vercel** (or Netlify), add both variables in your project's **Settings → Environment Variables**, then redeploy.

That's it. Open the app on your phone and your laptop — changes appear in real time on both.

---

## Push to GitHub

```bash
cd field-daily
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/field-daily.git
git push -u origin main
```

## Deploy for free

**Vercel** (easiest): [vercel.com](https://vercel.com) → sign in with GitHub → "Add New Project" → pick this repo → add the two env vars from step 5 above → Deploy. Auto-detects Vite.

**Netlify**: [netlify.com](https://netlify.com) → "Add new site → Import an existing project" → pick this repo. Build command `npm run build`, publish directory `dist`. Add env vars in Site settings → Environment variables.

---

## Adding or changing products

Open `src/App.jsx` and edit `PRODUCT_CATEGORIES` near the top. Each product needs a stable `id` (no spaces) and a `name`. Optional `sub` shows a subtitle. Existing counts stay tied to the old IDs, so don't rename them — remove and re-add if you need a fresh count.

## Sync status badge

The pill in the top-right tells you what's happening:

- **SYNCED** — connected to the backend, all changes are pushed live
- **SAVING** — currently pushing changes
- **OFFLINE** — can't reach the backend, changes save locally and will resync when reachable
- **LOCAL** — no backend configured, changes save to this browser only
- **CONNECTING** — initial connection on load

## About security

The setup script uses public read/write policies. That's fine when the app URL isn't publicly shared, because there's no easy way for a random person to find your Supabase project. If you want tighter security later (e.g. a login for Ashton, or a supervisor with read-only access), add Supabase Auth and swap the policies to check `auth.uid()`. Ask me and I'll wire it up.

## Stack

- React 18
- Vite
- Supabase (Postgres + Realtime)
- lucide-react (icons)
- Inter + JetBrains Mono via Google Fonts

---

## GitHub Pages notes

This project is a Vite/React app, so GitHub Pages cannot serve the source files directly unless the app is built first. This repo includes `.github/workflows/deploy.yml`, which builds the app and deploys the generated `dist/` folder automatically.

After pushing to GitHub:

1. Go to **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to **GitHub Actions**.
3. Push to the `main` branch.
4. Open the Actions tab and wait for **Deploy to GitHub Pages** to finish.
5. Optional sync: add `VITE_SUPABASE_URL` as an Actions variable and `VITE_SUPABASE_ANON_KEY` as an Actions secret before deploying. If you skip this, the app still works in local-only browser storage mode.

The Vite `base` is set to `./` so the app works correctly from a GitHub Pages project URL like `https://YOUR_USERNAME.github.io/field-daily/`.
