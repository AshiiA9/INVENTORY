-- Field Daily · Supabase setup
-- Paste this whole file into the Supabase SQL Editor and click "Run".
-- Safe to run more than once.

-- 1. The inventory table (one row, holding the whole state as JSON)
create table if not exists public.inventory (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- 2. Seed the single row the app reads/writes
insert into public.inventory (id, data)
values ('main', '{"garage":{},"truck":{},"notes":""}'::jsonb)
on conflict (id) do nothing;

-- 3. Enable Row Level Security
alter table public.inventory enable row level security;

-- 4. Public read/write policies
--    (fine for a single-tech tool at a private URL — see README for hardening)
drop policy if exists "public read" on public.inventory;
drop policy if exists "public insert" on public.inventory;
drop policy if exists "public update" on public.inventory;

create policy "public read"   on public.inventory for select using (true);
create policy "public insert" on public.inventory for insert with check (true);
create policy "public update" on public.inventory for update using (true) with check (true);

-- 5. Enable realtime so other devices see changes instantly
alter publication supabase_realtime add table public.inventory;
